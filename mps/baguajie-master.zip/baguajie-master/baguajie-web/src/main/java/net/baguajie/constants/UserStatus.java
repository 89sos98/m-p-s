package net.baguajie.constants;

public enum UserStatus {
	VALID, INVALID
}
