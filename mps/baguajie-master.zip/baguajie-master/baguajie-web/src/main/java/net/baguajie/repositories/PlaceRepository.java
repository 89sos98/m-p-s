package net.baguajie.repositories;

import net.baguajie.domains.Place;

public interface PlaceRepository extends
		AtomicOperationsRepository<Place, String> {

}
