package net.baguajie.constants;

public enum ResourceViewSize {
	THUMB, ORG, PIN
}
