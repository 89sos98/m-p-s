package net.baguajie.constants;

public enum ActivityType {
	SPOT, TRACK, FORWARD, FOLLOW, COMMENT, SETTING
}
