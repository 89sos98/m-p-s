package net.baguajie.constants;

public enum ByType {
	WEB, ANDROID, IPHONE, IPAD
}
