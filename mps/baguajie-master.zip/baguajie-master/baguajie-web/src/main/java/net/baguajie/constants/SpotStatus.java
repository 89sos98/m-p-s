package net.baguajie.constants;

public enum SpotStatus {
	VALID, INVALID
}
