package net.baguajie.constants;

public enum Gender {
	UNKNOWN, MALE, FEMALE 
}
