package net.baguajie.constants;

public enum AjaxResultCode {
	SUCCESS, INVALID, EXCEPTION, NEED_SIGNIN, NO_AUTH
}
