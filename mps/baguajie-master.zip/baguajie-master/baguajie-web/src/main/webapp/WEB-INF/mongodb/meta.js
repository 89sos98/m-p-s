db.cityMeta.insert(
		{"name" : "全国", "pinyin" : "quanguo", "lngLat" : [ 118.270087125, 33.504408779 ],"zoom" : 4, "createdAt" : new Date()});
db.cityMeta.insert(
		{'name': '杭州','pinyin':'hangzhou','lngLat':[120.17189024999996,30.261621415769714],'zoom':12, 'createdAt':new Date()});
db.cityMeta.insert(
		{'name': '南京','pinyin':'nanjing','lngLat':[118.73775064999988,32.072983734765536],'zoom':11, 'createdAt':new Date()});